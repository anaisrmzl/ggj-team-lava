namespace MobileConsole
{
    internal enum StyleType
    {
        LightBackground,
        DarkBackground,
        SelectedBackground,
        Text,
        SelectedText,
        ScrollbarBackground,
        ScrollbarHandle,
        ScrollBackground,
        LogBackground,
        LogCountBackground
    }
}