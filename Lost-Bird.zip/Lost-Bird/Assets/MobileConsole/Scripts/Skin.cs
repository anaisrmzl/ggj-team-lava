namespace MobileConsole
{
    internal enum Skin
    {
        Light,
        Dark
    }
}