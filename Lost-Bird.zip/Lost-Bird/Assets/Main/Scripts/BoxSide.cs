﻿public enum BoxSide
{
    Up,
    Down,
    Left,
    Right
}
